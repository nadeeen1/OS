package milestone1;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Vector;



public class OS {
		static String [][] memory = new String[60][2]; 
		//each process has 20 cells in the memory array (5 for PCB , 10 for unparsed code , 5 for variables)
	 	static String input;
	 	static Queue <Integer> ready = new LinkedList<>(); 	
	 	
	 	
	public static String getInput() {
		return input;
	}
	
	
	public static void setInput(String input) {
		OS.input = input;
	}
	
	
	public static void codeParser(String instruction , int d) throws FileNotFoundException, IOException, NumberFormatException, ParseException{
		String [] a = instruction.split("\\ ");
		switch(a[0]){
			case "assign" :
				if(a[2].equals("readFile")){
					String e = readMemory(a[3],d);
					String c = readFile(e);
					if(c!=null){
						writeMemory(a[1] , c , d);
					}
					else{
						return;
					}
				}
				if(a[2].equals("input")){
					String c = input();
					writeMemory(a[1],c,d);
				}
			break;
			case "writeFile" :
				if(readMemory(a[1],d) == null){
					if(readMemory(a[2],d)==null)
						writeFile(a[1],a[2]);
					else{
						writeFile(a[1],(String)readMemory(a[2],d));
					}
				}
				else{
					if(readMemory(a[2],d)==null)
						writeFile((String)readMemory(a[1],d),a[2]);
					else{
						writeFile((String)readMemory(a[1],d),(String)readMemory(a[2],d));
					}
				}
			break;
			case "add" : 
				add(a[1],a[2],d);
				break;
			case "readFile" : 
				
				if(readMemory(a[1],d)==null)
					readFile(a[1]);
				else{
					readMemory(a[1],d);
				}
			break;
			case "print" : 
				String m = readMemory(a[1],d);
				String z = readFile(m);
				if(a[1].length()>1){
					print(a[1]);
				}
				else{
					if(z!=null){
						print(z);
					}
					if(m!=null){
						print(m);
					}
				}
				
			break;
			default : 
			break;
			}
}

		
	//System call 1
	public static String readFile(String file) throws FileNotFoundException, IOException {
		String filename = "/Users/nadee/workspace/" + file + ".txt";
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			StringBuffer sb=new StringBuffer();
			String b;
			while ((b = br.readLine()) != null) {
				sb.append(b); 
				sb.append("\n");        
			}
			br.close();
			fr.close();
			return sb.toString();
		}
				    
		catch(Exception e) {
			return null;
		}
		
	}
	
	//System call 2
	public static void writeFile(String file,String input) throws FileNotFoundException, IOException{
		String filename = "/Users/nadee/workspace/" + file + ".txt";
		String n = null;
		if(readFile(input)!=null){
			  n = readFile(input);
			  FileWriter fw = new FileWriter(filename , true);
	          BufferedWriter bw = new BufferedWriter(fw);
	          PrintWriter out = new PrintWriter(bw);
	        	  if(n==null)
	        		  out.append(input);
	        	  else{
	        		  out.write(n);
	        		  //out.append(n);
	        		  System.out.println("Successfully wrote input to file!");
	        	  }
	          out.close();
	          bw.close();
	          fw.close();
		}
			}
		

	//System call 3
	public static void print(String data) { 
		System.out.println(data);
	}
	
	//System call 4
	public static String input(){
		print("Please enter data : ");
		Scanner sc = new Scanner(System.in);
		OS.setInput(sc.nextLine());
		return input;
	}
	
	//System Call 5 altered to read from assigned memory space of process 
	public static String readMemory(String a , int PID){
		int index=0;
		int end = 0;
		switch(PID){
				case 1 : index = 5;
						 end = 20;
						 break;
				case 2: index = 25;
						end = 40;
						break;
				case 3: index = 45;
						end = 60;
						break;
			}
			String c = "";
			Boolean contains = false;
			int r = 0;
			for(int i = index ; i<end ; i++){
				if(memory[i][0]!=null && (memory[i][0]).equals(a)){
					contains=true;
					r=i;
					break;
				}
			}
			if(contains == true){
				c= "" + memory[r][1];
			}
			if(contains == false)
				return null;
			else
				System.out.println("Reading " + a + " from the memory at index " + r);
			return c;
		}
	
	//System call 6 altered to write in assigned memory space of process
	public static void writeMemory(Object a , Object b , int PID){
		int index=0;
		int end = 0;
		switch(PID){
				case 1 : index = 15;
						 end = 20;
						 break;
				case 2: index = 35;
						end = 40;
						break;
				case 3: index = 55;
						end = 60;
						break;
				default: System.out.println("Invalid process ID");
			}
		Boolean contains = false;
		int r=0;
		for(int i = index ; i<end ; i++){
			if((memory[i][0]).equals((String)a)){
				contains=true;
				r=i;
				break;
			}
		}
		if(contains==true){
			memory[r][1]=b+"";
			System.out.println("Successfully wrote to memory!");
			return;
		}
		else{
			for(int j = index; j<end ; j++){
				if(memory[j][0] == null){
					memory[j][0]=a+"";
					memory[j][1]=b+"";
				}
			}
		}
		System.out.println("Writing " + b + " to the memory at index " + r);
		
		
		
	
			}
	
	//Assign function
	public static void assign(Object x, Object y, int PID){
		if(y instanceof String){
			if(readMemory(""+y,PID)==null){
			writeMemory(x,(String)y , PID);
			}
			else{
					writeMemory(x,readMemory(""+y , PID),PID);}
				
			}
			else {
				if(y instanceof Integer){
					if(readMemory(""+y,PID)==null)
						writeMemory(x,(Integer)y , PID);
					else
						writeMemory(x,Integer.parseInt(readMemory(""+y , PID)) , PID);
				}
			}
	}
	
	//Add function
	public static void add(Object x , Object y , int PID) throws NullPointerException {
		try{
			String a1 = readMemory(""+x , PID);
			int x1 = Integer.parseInt(a1);
			String a2 = readMemory(""+y , PID);
			int y1 = Integer.parseInt(a2);
			int f = x1+y1;
			writeMemory(x,""+f , PID);
		}
		catch(Exception e){
			System.out.println("file entered doesn't exist!");
		}
	}
	
	//method responsible for assigning memory space for each process
	public static void assignMem(String fileName) throws FileNotFoundException, IOException{
		setPCB(fileName);
		String [] t = variable(fileName);
		int d = Integer.parseInt(fileName.charAt(fileName.length()-1)+"");
		int index=0;
		int end = 0;
		switch(d){
				case 1 : index = 15;
						 end = 20;
						 break;
				case 2: index = 35;
						end = 40;
						break;
				case 3: index = 55;
						end = 60;
						break;
				default: System.out.println("Invalid process ID");
			}
		int z=0;
		for(int i=index ; i<end ; i++){
			if(t[z]!=null){
					memory[i][0]=t[z];
					memory[i][1]=null;
					z++;
			}
		}
		int index2 =0;
		int end2=0;
		switch(d){
		case 1 : index2 = 5;
				 end2 = 14;
				 break;
		case 2: index2 = 25;
				end2 = 34;
				break;
		case 3: index2 = 45;
				end2 = 54;
				break;
		default: System.out.println("Invalid process ID");
	}
		
		String p = readFile(fileName);
		String[] lines = p.split("\\n");
		int k=0;
		for(int i=index2 ; i<=end2 ; i++){
			if(k<lines.length){
				memory[i][0]="Line"+k;
				memory[i][1]=lines[k];
				k++;
			}
			else
				break;
			
		}
}
	
	//initialize PCB of each process and place in assigned process memory space
	public static void setPCB(String fileName){
		PCB r = new PCB();
		switch(fileName){
		case "Program 1":
			PCB pcb1 = new PCB();
			pcb1.setPc(0);
			pcb1.setPid(1);
			pcb1.setRunning(false);
			pcb1.setLower(0);
			pcb1.setUpper(19);
			memory[0][0]="PC";
			memory[0][1]=pcb1.pc+"";
			memory[1][0]="PID";
			memory[1][1]=pcb1.pid+"";
			memory[2][0]="State";
			memory[2][1]=pcb1.running+"";
			memory[3][0]="low";
			memory[3][1]=pcb1.lower+"";
			memory[4][0]="up";
			memory[4][1]=pcb1.upper+"";
			r=pcb1;
			break;
		case "Program 2":
			PCB pcb2 = new PCB();
			pcb2.setPc(0);
			pcb2.setPid(2);
			pcb2.setRunning(false);
			pcb2.setLower(20);
			pcb2.setUpper(39);
			memory[20][0]="PC";
			memory[20][1]=pcb2.pc+"";
			memory[21][0]="PID";
			memory[21][1]=pcb2.pid+"";
			memory[22][0]="State";
			memory[22][1]=pcb2.running+"";
			memory[23][0]="low";
			memory[23][1]=pcb2.lower+"";
			memory[24][0]="up";
			memory[24][1]=pcb2.upper+"";
			r=pcb2;
			break;
		case "Program 3":
			PCB pcb3 = new PCB();
			pcb3.setPc(0);
			pcb3.setPid(3);
			pcb3.setRunning(false);
			pcb3.setLower(40);
			pcb3.setUpper(59);
			memory[40][0]="PC";
			memory[40][1]=pcb3.pc+"";
			memory[41][0]="PID";
			memory[41][1]=pcb3.pid+"";
			memory[42][0]="State";
			memory[42][1]=pcb3.running+"";
			memory[43][0]="low";
			memory[43][1]=pcb3.lower+"";
			memory[44][0]="up";
			memory[44][1]=pcb3.upper+"";
			r=pcb3;
			break;
			default: System.out.println("Please Enter correct program name");
			break;
		}
		
	}
	
	//returns number of variables in each process
	public static String [] variable(String fileName) throws FileNotFoundException, IOException{
		String p = readFile(fileName);
		String[] lines = p.split("\\n");
		String [][] f = new String[lines.length][];
		for(int k=0;k<lines.length;k++){
			f[k]=lines[k].split("\\ ");
		}
		String temp = "";
		String [] a = new String[5];
		int c=0;
		for(int g=0;g<f.length;g++){
			for(int e=0;e<f[g].length;e++){
				if(temp.contains(f[g][e]) == false && f[g][e].length()==1){
					temp=temp+f[g][e];
					a[c]=f[g][e];
					c++;
				}
					
			}
		}
		return a;
	}

	//retrieves process IDs from the PCB stored in memory and adds them to the ready queue and calls the scheduler
	public static void Execute() throws NumberFormatException, FileNotFoundException, IOException, ParseException{
		int pid1 = Integer.parseInt(memory[1][1]);
		int pid2 = Integer.parseInt(memory[21][1]);
		int pid3 = Integer.parseInt(memory[41][1]);
		ready.add(pid1);
		ready.add(pid2);
		ready.add(pid3);
		scheduler();
	}
	
	//schedules the processes according to Round Robin algorithm
	public static void scheduler() throws NumberFormatException, FileNotFoundException, IOException, ParseException{
		int timeSlice = 2;
		int pc1=Integer.parseInt(memory[0][1]);
		int pc2=Integer.parseInt(memory[20][1]);
		int pc3=Integer.parseInt(memory[40][1]);
		int Quanta1 = 0;
		int Quanta2 = 0;
		int Quanta3 = 0;
		while(!(ready.isEmpty())){
			int i = ready.peek();
			switch(i){
			case 1 : 
				Quanta1++;
				System.out.println("Process 1 is running");
				memory[2][1]=true + "";
				String t1 = readMemory("Line"+pc1,i);
				if(t1 == null){
					ready.remove(1);
					i=ready.peek();
					try{
						i=ready.peek();
					}
					catch(NullPointerException e){
						System.out.println("Ready queue is empty and all processes finished execution");
						return;
					}
					System.out.println("Process 1 terminated and ran 0 quanta!");
					break;
				}
				codeParser(t1,i);
				pc1++;
				timeSlice--;
				String t2 = readMemory("Line"+pc1,i);
				if(t2 == null){
					ready.remove(1);
					i=ready.peek();
					try{
						i=ready.peek();
					}
					catch(NullPointerException e){
						System.out.println("Ready queue is empty and all processes finished execution");
						return;
					}
					System.out.println("Process 1 terminated and ran 1 quanta!");
					break;
				}
				codeParser(t2,i);
				pc1++;
				timeSlice--;
				ready.remove(1);
				i=ready.peek();
				ready.add(1);
				timeSlice+=2;
				memory[0][1]=pc1 + "";
				memory[2][1]=false+"";
				System.out.println("Process 1 ran 2 quanta!");
				if(ready.isEmpty()){
					return;
				}
				break;
			case 2 :
				System.out.println("Process 2 is running");
				memory[22][1]=true + "";
				String z1 = readMemory("Line"+pc2,i);
				if(z1 == null){
					ready.remove(2);
					i=ready.peek();
					try{
						i=ready.peek();
					}
					catch(NullPointerException e){
						System.out.println("Ready queue is empty and all processes finished execution");
						return;
					}
					System.out.println("Process 2 terminated and ran 0 quanta!");
					break;
				}
				codeParser(z1,i);
				pc2++;
				timeSlice--;
				String z2 = readMemory("Line"+pc2,i);
				if(z2 == null){
					ready.remove(2);
					i=ready.peek();
					try{
						i=ready.peek();
					}
					catch(NullPointerException e){
						System.out.println("Ready queue is empty and all processes finished execution");
						return;
					}
					System.out.println("Process 2 terminated and ran 1 quanta!");
					break;
				}
				codeParser(z2,i);
				pc2++;
				timeSlice--;
				ready.remove(2);
				i=ready.peek();
				ready.add(2);
				timeSlice+=2;
				memory[20][1]=pc2 + "";
				memory[22][1]=false+"";
				System.out.println("Process 2 ran 2 quanta!");
				if(ready.isEmpty()){
					return;
				}
				break;
			case 3 :
				System.out.println("Process 3 is running");
				memory[42][1]=true + "";
				String r1 = readMemory("Line"+pc3,i);
				if(r1 == null){
					ready.remove(3);
					try{
						i=ready.peek();
					}
					catch(NullPointerException e){
						System.out.println("Ready queue is empty and all processes finished execution");
						return;
					}
					System.out.println("Process 3 terminated and ran 0 quanta!");
					break;
				}
				codeParser(r1,i);
				pc3++;
				timeSlice--;
				String r2 = readMemory("Line"+pc3,i);
				if(r2 == null){
					ready.remove(3);
					i=ready.peek();
					try{
						i=ready.peek();
					}
					catch(NullPointerException e){
						System.out.println("Ready queue is empty and all processes finished execution");
						return;
					}
					System.out.println("Process 3 terminated and ran 1 quanta!");
					break;
				}
				codeParser(r2,i);
				pc3++;
				timeSlice--;
				ready.remove(3);
				i=ready.peek();
				ready.add(3);
				timeSlice+=2;
				memory[40][1]=pc3 + "";
				memory[42][1]=false+"";
				System.out.println("Process 3 ran 2 quanta!");
				if(ready.isEmpty()){
					return;
				}
				break;
			default :
					System.out.println("Ready queue is empty and all processes finished execution");
					return;
			}
		}
		return;
	}
	
	
	//main method that calls code parser on 3 programs sequentially then terminates
	public static void main(String[]args) throws FileNotFoundException, IOException, NumberFormatException, ParseException{
		assignMem("Program 1");
		assignMem("Program 2");
		assignMem("Program 3");
		
		//Printing entire Memory including PCB,variables,& unparsed lines of code after memory creation
		System.out.println("Memory");
		for(int i=0 ; i<memory.length ; i++){
			System.out.println("Index:"+i+" " + memory[i][0] + " :" + memory[i][1]);
		}
		
		
		Execute();
		
		System.out.println("Memory");
		for(int i=0 ; i<memory.length ; i++){
			System.out.println("Index:"+i+" " + memory[i][0] + " :" + memory[i][1]);
		}
		}


	
}



